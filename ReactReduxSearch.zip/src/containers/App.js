import React, { Component } from 'react';
import Search from './Search/search.js';
import MoviesList from '../components/MoviesList/moviesList';
import Details from '../components/MoviesList/details';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { onSearchChange } from '../actions/searchActions'
import { getMovies,onMovieChoose } from '../actions/moviesActions';
class App extends Component { 
    render() {

        const {value,onSearchChange,onMovieChoose,getMovies,movies,currentMovieId} = this.props;

        return (
            <div className="app">
                <Search value={value} getMovies={getMovies} onSearchChange={onSearchChange}/>
                <Details movieId={currentMovieId}/>
                <MoviesList moviesList={movies} onMovieChoose={onMovieChoose}/>
            </div>
        );
    }
}
const mapStateToProps = (state) => {
    return {
        value: state.search.value,
        movies: state.movies.movies,
        currentMovieId: state.movies.currentMovieId
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        onSearchChange: bindActionCreators( onSearchChange, dispatch),
        getMovies: bindActionCreators(getMovies,dispatch),
        onMovieChoose: bindActionCreators( onMovieChoose, dispatch)
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(App);