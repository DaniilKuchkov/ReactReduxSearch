import React from 'react'
import { render } from 'react-dom'
import { createStore, applyMiddleware } from 'redux'
import { Provider } from 'react-redux'
import App from './containers/App'
import Details from './components/MoviesList/details'
import reducer from './reducers'
import{ createLogger} from 'redux-logger'
import thunk from 'redux-thunk';
import { HashRouter, Route, Link } from 'react-router-dom';

const store = createStore(reducer,applyMiddleware(createLogger(),thunk))

render(
  <Provider store={store}>
    <HashRouter>
      <div>
        <Route  path="/" component={App}/>
        <Route path="(:movieId)" component={Details} />
      </div>
    </HashRouter>
  </Provider>,
  document.getElementById('root')
)
